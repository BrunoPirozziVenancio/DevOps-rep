# Terraform - OCI | VCN + Instância  

